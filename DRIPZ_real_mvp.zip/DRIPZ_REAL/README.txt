DRIPZ REAL MVP

index.html = klientų parduotuvė
admin.html = prekių ir užsakymų valdymas

Ši versija paleidžiama iš karto, tačiau duomenys saugomi naršyklės localStorage. Tai reiškia, kad ji nėra dar tikra daugelio klientų internetinė parduotuvė su bendra duomenų baze.

Nemokamam paleidimui: įkelkite index.html į GitHub Pages.

Norint pilnos produkcinės versijos reikia prijungti Supabase/Firebase duomenų bazei, saugų administravimą ir Stripe/PayPal mokėjimus. Niekada nelaikykite slaptų mokėjimų raktų HTML faile.
